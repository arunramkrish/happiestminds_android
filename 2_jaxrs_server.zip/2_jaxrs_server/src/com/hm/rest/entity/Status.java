package com.hm.rest.entity;

public enum Status {
	ACTIVE, LOCKED, DISABLED, CLOSED;
}
